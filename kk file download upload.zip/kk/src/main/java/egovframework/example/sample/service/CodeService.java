package egovframework.example.sample.service;

import java.util.List;


import egovframework.id01.vo.CodeVO;

public interface CodeService {
	
	public String insertCodes(CodeVO vo) throws Exception;
	public List<?> SelectCodesList(CodeVO vo) throws Exception;
	public CodeVO selectCodeDetail(String name) throws Exception;
	public int updateCode(CodeVO vo) throws Exception;
}
