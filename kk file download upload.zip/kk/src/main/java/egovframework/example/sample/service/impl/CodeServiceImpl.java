package egovframework.example.sample.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import egovframework.id01.vo.CodeVO;
import egovframework.example.sample.service.CodeService;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;

@Service("codeService")
public class CodeServiceImpl implements CodeService {
	
	@Resource(name="codeDAO")
	private CodeDAO codeDAO;
	
	
	/** ID Generation */
	@Resource(name = "egovIdGnrServiceCode")
	private EgovIdGnrService egovIdGnrServiceCode;
	
	
	

	@Override
	public String insertCodes(CodeVO vo) throws Exception {
		
		/** ID Generation Service */
		String CodeId = egovIdGnrServiceCode.getNextStringId();
		vo.setId(CodeId);
		


		codeDAO.insertCodes(vo);

		return CodeId;
	}




	@Override
	public List<?> SelectCodesList(CodeVO vo) throws Exception {
		// TODO Auto-generated method stub
		return codeDAO.selectCodesList(vo);
	}




	@Override
	public CodeVO selectCodeDetail(String name) throws Exception {
		// TODO Auto-generated method stub
		return codeDAO.selectCodeDetail(name);
	}




	@Override
	public int updateCode(CodeVO vo) throws Exception {
		// TODO Auto-generated method stub
		return codeDAO.updateCode(vo);
	}









	
	
	
	

}