package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;


import egovframework.id01.vo.CodeVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("codeDAO")
public class CodeDAO extends EgovAbstractDAO {
	
	public String insertCodes(CodeVO vo) throws Exception {
		// TODO Auto-generated method stub
		return (String)insert("codeDAO.insertCodes",vo);
	}

	public List<?> selectCodesList(CodeVO vo) throws Exception {
		// TODO Auto-generated method stub
		return (List<?>)list("codeDAO.selectCodesList");
	}

	public CodeVO selectCodeDetail(String name) {
		// TODO Auto-generated method stub
		return (CodeVO)select("codeDAO.selectCodeDetail",name);
	}

	public int updateCode(CodeVO vo) {
		// TODO Auto-generated method stub
		return (int)update("codeDAO.updateCode",vo);
	}



}
