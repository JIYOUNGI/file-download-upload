package egovframework.id01.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import egovframework.example.sample.service.CodeService;
import egovframework.id01.vo.CodeVO;


@Controller
public class CodeController {
	
	@Resource(name="codeService")
	private CodeService codeService;
	
	@RequestMapping(value="codeWrite.do")
	public String codeWrtie() {
		
		
		return "codeWrite";
	}
	
//	@RequestMapping(value="codeWriteSave.do")
//	public String insertCode(CodeVO vo) throws Exception {
//		     
//		//String result = null; 값이 되야 성공임 (insert특징)
//		String result = codeService.insertCodes(vo);
//		
//		
//	System.out.println("id----------->"+vo.getId());
////		System.out.println(vo.getGid());
////		System.out.println(vo.getName());
//		if( result == null ) {   // ok
//			System.out.println("저장완료");
//		} else {
//			System.out.println("저장실패");
//		}
//		return "redirect:codeList.do";
//	}
//	
	@RequestMapping(value="codeWriteSave.do")
	public String insertCode(CodeVO codeVo) throws Exception {
		
		// 파일 업로드 처리
        String fileName = null;
        MultipartFile uploadFile = codeVo.getUploadFile();
        if (!uploadFile.isEmpty()) {
            String originalFileName = uploadFile.getOriginalFilename();
            String ext = FilenameUtils.getExtension(originalFileName); // 확장자 구하기
            UUID uuid = UUID.randomUUID(); // UUID 구하기
            fileName = uuid + "." + ext;
            uploadFile.transferTo(new File("C:\\upload\\" + fileName));
        }
        codeVo.setFileName(fileName);
 
        System.out.println(codeVo.getFileName());
 
        String result = codeService.insertCodes(codeVo);
		     
		//String result = null; 값이 되야 성공임 (insert특징)
		//String result = codeService.insertCodes(vo);
		
        System.out.println("filename----------->"+codeVo.getFileName());
//	System.out.println("id----------->"+codeVo.getId());
//		System.out.println(vo.getGid());
//		System.out.println(vo.getName());
		if( result == null ) {   // ok
			System.out.println("저장완료");
		} else {
			System.out.println("저장실패");
		}
		return "redirect:codeList.do";
	}
	
	// 글쓰기
//    @RequestMapping(value = "/insertTest.do")
//    public String write(@ModelAttribute("codeVo") CodeVO codeVo) throws Exception {
// 
//        // 파일 업로드 처리
//        String fileName = null;
//        MultipartFile uploadFile = codeVo.getUploadFile();
//        if (!uploadFile.isEmpty()) {
//            String originalFileName = uploadFile.getOriginalFilename();
//            String ext = FilenameUtils.getExtension(originalFileName); // 확장자 구하기
//            UUID uuid = UUID.randomUUID(); // UUID 구하기
//            fileName = uuid + "." + ext;
//            uploadFile.transferTo(new File("D:\\upload\\" + fileName));
//        }
//        codeVo.setFileName(fileName);
// 
//        System.out.println(codeVo.getFileName());
// 
//        codeService.insertTest(codeVo);
// 
//        return "redirect:testList.do";
//    }
	
	
	@RequestMapping(value="codeList.do")
	public String selectDeptList(CodeVO vo,ModelMap model) throws Exception {
		
		List<?> list = codeService.SelectCodesList(vo);
		
	//	System.out.println(list);
		model.addAttribute("resultList", list);
	
		return "codeList";
	}
	
	@RequestMapping(value="codeDetail.do")
	public String selectCodeDetail(String name,ModelMap model) throws Exception{

		CodeVO vo = codeService.selectCodeDetail(name);
		model.addAttribute("vo",vo);

		return "codeDetail";

	}
	
	@RequestMapping(value = "fileDownload.do")
    public void fileDownload(HttpServletRequest request, HttpServletResponse response) throws Exception {
 
        String filename = request.getParameter("fileName");
        String realFilename = "";
        System.out.println(filename);
 
        try {
 
            String browser = request.getHeader("User-Agent");
            // 파일 인코딩
            if (browser.contains("MSIE") || browser.contains("Trident") || browser.contains("Chrome")) {
                filename = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
            } else {
                filename = new String(filename.getBytes("UTF-8"), "ISO-8859-1");
            }
 
        } catch (UnsupportedEncodingException e) {
 
            System.out.println("UnsupportedEncodingException 발생");
 
        }
 
        realFilename = "C:\\upload\\" + filename;
        System.out.println(realFilename);
 
        File file = new File(realFilename);
        if (!file.exists()) {
            return;
        }
 
        // 파일명 지정
        response.setContentType("application/octer-stream");
        response.setHeader("Content-Transfer-Encoding", "binary");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
 
        try {
            OutputStream os = response.getOutputStream();
            FileInputStream fis = new FileInputStream(realFilename);
 
            int cnt = 0;
            byte[] bytes = new byte[512];
 
            while ((cnt = fis.read(bytes)) != -1) {
                os.write(bytes, 0, cnt);
            }
 
            fis.close();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
 
    }
	
	
	@RequestMapping(value="codeModifyWrite.do")
	public String codeModifyWrite(String name,ModelMap model) throws Exception {
		CodeVO vo = codeService.selectCodeDetail(name);
		model.addAttribute("codevo",vo);
		
		return "codeModifyWrite";
	}
	
	@RequestMapping(value="codeModifySave.do")
	public String updateCode(CodeVO codeVo) throws Exception {
		
		// 파일 업로드 처리
        String fileName = null;
        MultipartFile uploadFile = codeVo.getUploadFile();
        if (!uploadFile.isEmpty()) {
            String originalFileName = uploadFile.getOriginalFilename();
            String ext = FilenameUtils.getExtension(originalFileName); // 확장자 구하기
            UUID uuid = UUID.randomUUID(); // UUID 구하기
            fileName = uuid + "." + ext;
            uploadFile.transferTo(new File("C:\\upload\\" + fileName));
             codeVo.setFileName(fileName);
	}else{
        codeService.updateCode(codeVo);
        return "redirect:codeDetail.do?name=" + codeVo.getName();
    }
    
        int result = codeService.updateCode(codeVo);
        System.out.println("updatefilename"+codeVo.getFileName());
        System.out.println("updateuploadfilename"+codeVo.getUploadFile());
		if( result == 1 ) {   // ok
			System.out.println("저장완료");
		} else {
			System.out.println("저장실패");
		}
        return "redirect:codeList.do";
}


}
	

	
	


