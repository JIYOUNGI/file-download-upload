package egovframework.id01.vo;

import org.springframework.web.multipart.MultipartFile;

public class CodeVO {
	
	private String id;
	private int gid;
	private String name;
	
	//파일추가
private String fileName;
private MultipartFile uploadFile;


	
	
	public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
public MultipartFile getUploadFile() {
	return uploadFile;
}
public void setUploadFile(MultipartFile uploadFile) {
	this.uploadFile = uploadFile;
}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	

}
